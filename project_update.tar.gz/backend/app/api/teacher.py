from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

from app.core.database import get_db
from app.api.auth import get_current_user
from app.models.models import (
    User, UserRole, Teacher, TeacherAssignment, AttendanceSession, 
    AttendanceRecord, Student, SessionStatus
)

router = APIRouter(prefix="/teacher", tags=["Teacher Mobile Workflow"])

def require_teacher(current_user: User = Depends(get_current_user)) -> Teacher:
    if current_user.role != UserRole.TEACHER or not current_user.teacher_profile:
        raise HTTPException(status_code=403, detail="Teacher permission required")
    return current_user.teacher_profile

class StartSessionRequest(BaseModel):
    subject_id: int
    section_id: int
    period: str
    date: Optional[str] = None # Defaults to YYYY-MM-DD

from app.core.security import get_server_ist_date
from app.core.device_security import log_security_audit_event, SecurityEventType

@router.get("/assigned-classes")
def get_assigned_classes(db: Session = Depends(get_db), current_teacher: Teacher = Depends(require_teacher)):
    assignments = db.query(TeacherAssignment).filter(TeacherAssignment.teacher_id == current_teacher.id).all()
    res = []
    for a in assignments:
        res.append({
            "assignment_id": a.id,
            "subject_id": a.subject_id,
            "subject_code": a.subject.code if a.subject else "",
            "subject_name": a.subject.name if a.subject else "",
            "section_id": a.section_id,
            "section_name": a.section.name if a.section else "",
            "department": a.section.department.code if a.section and a.section.department else "",
            "year": a.section.academic_year.name if a.section and a.section.academic_year else ""
        })
    return res

@router.post("/sessions/start")
def start_attendance_session(req: StartSessionRequest, db: Session = Depends(get_db), current_teacher: Teacher = Depends(require_teacher)):
    # 1. Authorize: Verify teacher assignment
    assignment = db.query(TeacherAssignment).filter(
        TeacherAssignment.teacher_id == current_teacher.id,
        TeacherAssignment.subject_id == req.subject_id,
        TeacherAssignment.section_id == req.section_id
    ).first()

    if not assignment:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Teacher is not authorized or assigned to this subject and class section."
        )

    date_str = req.date or get_server_ist_date()

    # Check existing active session for same subject/section/period/date
    existing = db.query(AttendanceSession).filter(
        AttendanceSession.teacher_id == current_teacher.id,
        AttendanceSession.subject_id == req.subject_id,
        AttendanceSession.section_id == req.section_id,
        AttendanceSession.period == req.period,
        AttendanceSession.session_date == date_str
    ).first()

    if existing:
        return {
            "session_id": existing.id,
            "status": existing.status.value,
            "session_date": existing.session_date,
            "message": "Resumed existing attendance session"
        }

    new_session = AttendanceSession(
        teacher_id=current_teacher.id,
        subject_id=req.subject_id,
        section_id=req.section_id,
        period=req.period,
        session_date=date_str,
        status=SessionStatus.OPEN
    )
    db.add(new_session)
    db.commit()
    db.refresh(new_session)

    return {
        "session_id": new_session.id,
        "status": new_session.status.value,
        "session_date": new_session.session_date,
        "message": "Started new attendance session"
    }

@router.get("/historical-sessions")
def get_historical_sessions(
    date: Optional[str] = None,
    db: Session = Depends(get_db),
    current_teacher: Teacher = Depends(require_teacher)
):
    query = db.query(AttendanceSession).filter(AttendanceSession.teacher_id == current_teacher.id)
    if date:
        query = query.filter(AttendanceSession.session_date == date)
    
    sessions = query.order_by(AttendanceSession.created_at.desc()).all()
    res = []
    for s in sessions:
        total_students = db.query(Student).filter(Student.section_id == s.section_id).count()
        records = db.query(AttendanceRecord).filter(AttendanceRecord.session_id == s.id).all()
        present_count = sum(1 for r in records if r.status.value in ["PRESENT", "4"])
        absent_count = max(0, total_students - present_count)

        res.append({
            "session_id": s.id,
            "subject_id": s.subject_id,
            "subject_name": s.subject.name if s.subject else "",
            "subject_code": s.subject.code if s.subject else "",
            "section_id": s.section_id,
            "section_name": s.section.name if s.section else "",
            "period": s.period,
            "session_date": s.session_date,
            "status": s.status.value,
            "total_students": total_students,
            "present_count": present_count,
            "absent_count": absent_count,
            "created_at": s.created_at.isoformat() if s.created_at else ""
        })
    return res

@router.get("/sessions/{session_id}")
def get_session_details(session_id: int, db: Session = Depends(get_db), current_teacher: Teacher = Depends(require_teacher)):
    session = db.query(AttendanceSession).filter(AttendanceSession.id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Attendance session not found")

    if session.teacher_id != current_teacher.id:
        raise HTTPException(status_code=403, detail="You are not authorized to view this session")

    total_section_students = db.query(Student).filter(Student.section_id == session.section_id).all()
    records = db.query(AttendanceRecord).filter(AttendanceRecord.session_id == session_id).all()
    scanned_rolls = {r.roll_number: r.status.value for r in records}

    students_list = []
    present_count = 0
    absent_count = 0

    for s in total_section_students:
        status_val = scanned_rolls.get(s.roll_number, "ABSENT")
        if status_val in ["PRESENT", "4"]:
            present_count += 1
        else:
            absent_count += 1

        students_list.append({
            "student_id": s.id,
            "roll_number": s.roll_number,
            "name": s.name,
            "status": status_val,
            "is_scanned": s.roll_number in scanned_rolls
        })

    return {
        "session_id": session.id,
        "subject_name": session.subject.name if session.subject else "",
        "section_name": session.section.name if session.section else "",
        "period": session.period,
        "session_date": session.session_date,
        "status": session.status.value,
        "total_students": len(total_section_students),
        "present_count": present_count,
        "absent_count": absent_count,
        "students": students_list
    }

from app.api.attendance import invalidate_session_cache

@router.post("/sessions/{session_id}/lock")
def lock_session(session_id: int, db: Session = Depends(get_db), current_teacher: Teacher = Depends(require_teacher)):
    session = db.query(AttendanceSession).filter(AttendanceSession.id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    if session.teacher_id != current_teacher.id:
        raise HTTPException(status_code=403, detail="Not authorized to lock this session")
    
    session.status = SessionStatus.LOCKED
    session.locked_at = datetime.utcnow()
    db.commit()
    invalidate_session_cache(session_id)

    log_security_audit_event(
        db=db,
        event_type=SecurityEventType.ATTENDANCE_SUBMITTED,
        action="SESSION_LOCKED",
        details=f"Session {session_id} locked by teacher {current_teacher.name}",
        user_id=current_teacher.user_id
    )

    return {"message": "Attendance session locked successfully"}

@router.post("/sessions/{session_id}/unlock")
def unlock_session(session_id: int, db: Session = Depends(get_db), current_teacher: Teacher = Depends(require_teacher)):
    session = db.query(AttendanceSession).filter(AttendanceSession.id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    if session.teacher_id != current_teacher.id:
        raise HTTPException(status_code=403, detail="Not authorized to unlock this session")
    
    session.status = SessionStatus.OPEN
    session.locked_at = None
    db.commit()
    invalidate_session_cache(session_id)

    log_security_audit_event(
        db=db,
        event_type=SecurityEventType.ATTENDANCE_SUBMITTED,
        action="SESSION_UNLOCKED",
        details=f"Session {session_id} unlocked for historical editing by teacher {current_teacher.name}",
        user_id=current_teacher.user_id
    )

    return {"message": "Attendance session unlocked successfully for historical editing"}

class TeacherSettingsRequest(BaseModel):
    google_sheet_id: str

def extract_spreadsheet_id(input_str: str) -> str:
    if not input_str:
        return ""
    s = input_str.strip()
    if "/d/" in s:
        parts = s.split("/d/")
        if len(parts) > 1:
            return parts[1].split("/")[0]
    return s

@router.get("/profile")
def get_teacher_profile(db: Session = Depends(get_db), current_teacher: Teacher = Depends(require_teacher)):
    sp_id = current_teacher.google_sheet_id or ""
    sp_url = f"https://docs.google.com/spreadsheets/d/{sp_id}/edit" if sp_id else ""
    return {
        "id": current_teacher.id,
        "teacher_code": current_teacher.teacher_code,
        "name": current_teacher.name,
        "department": current_teacher.department.name if current_teacher.department else "",
        "mobile": current_teacher.mobile or "",
        "google_sheet_id": sp_id,
        "google_sheet_url": sp_url
    }

@router.put("/settings")
def update_teacher_settings(req: TeacherSettingsRequest, db: Session = Depends(get_db), current_teacher: Teacher = Depends(require_teacher)):
    sp_id = extract_spreadsheet_id(req.google_sheet_id)
    current_teacher.google_sheet_id = sp_id
    db.commit()
    sp_url = f"https://docs.google.com/spreadsheets/d/{sp_id}/edit" if sp_id else ""
    return {
        "message": "Teacher Google Sheet configuration updated successfully",
        "google_sheet_id": sp_id,
        "google_sheet_url": sp_url
    }

